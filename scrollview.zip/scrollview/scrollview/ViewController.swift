//
//  ViewController.swift
//  scrollview
//
//  Created by MACOS on 11/19/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var src: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        src.contentSize = CGSize(width: self.view.frame.size.width, height: 700);
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

